"""
Passenger WSGI Configuration for cPanel
This file is required for deploying Flask apps on cPanel with Passenger
"""

import sys
import os

# Add your application directory to the Python path
CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, CURRENT_DIR)

# Load environment variables from .env file
from dotenv import load_dotenv
env_path = os.path.join(CURRENT_DIR, '.env')
if os.path.exists(env_path):
    load_dotenv(env_path, override=True)

# Create database directory if it doesn't exist
db_dir = os.path.join(CURRENT_DIR, 'database')
if not os.path.exists(db_dir):
    os.makedirs(db_dir)

# Import your Flask app
try:
    from app import app as application
except Exception as e:
    # If import fails, create a simple error app for debugging
    from flask import Flask
    application = Flask(__name__)
    
    @application.route('/')
    def error_page():
        return f"""
        <h1>Application Error</h1>
        <p>Failed to load the main application.</p>
        <p><strong>Error:</strong> {str(e)}</p>
        <p>Please check the error logs in cPanel.</p>
        """, 500

# This is required for Passenger
if __name__ == '__main__':
    application.run()
